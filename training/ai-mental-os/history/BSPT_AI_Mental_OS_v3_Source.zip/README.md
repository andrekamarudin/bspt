# BSPT AI Mental OS, Version 3

**Purpose:** 26-slide, editable PowerPoint. Same paid curriculum and 150-minute facilitation as v2. V3 adds recognizable visual continuity without turning every slide into the same template.

## Changes in V3

- BSPT / FIELD NOTES signature in the header, source-derived brush image on each standard slide.
- Five consistent chapter markers: Human Problem, Mental Shift, Define Done, Verify + Delegate, Your Own Use Case.
- A thin coral progress line advances as the deck proceeds, uniting varied layouts and signalling forward momentum.
- Official GitHub motif SVG geometry: marker swash, hand arrow, and paperclip. Swashes emphasize only pivotal text. One hand-arrow points into the traceable decision register; tape/clip are applied to actual paper worksheets.
- Short informal annotations use a handwriting-style fallback, anchored to relevant content.
- **2 one-shot, non-looping animated GIFs** on the learner's new use-case reveal (slide 23) and the closing payoff (slide 25). These are made from the previously extracted, source-exact brush silhouette geometry, not a retrieved copy of the repository's original motion GIF. The final frame uses canonical coral orange.
- Presenter notes and underlying core learning content unchanged.

## Build

From this directory:

```bash
npm install
node generate.js
```

The generated file is `BSPT_AI_Mental_OS_Training_v3.pptx`.

## Verification

- Rendered all 26 slides using LibreOffice and visually inspected contact sheet and key full-resolution slides.
- No off-slide overflow in the slides structural test.
- 26 notes slides preserved.
- GIFs remain embedded as multi-frame GIF media, each 31 frames with no loop tag.
- **Native Microsoft PowerPoint playback has not been tested**. GIFs should be reviewed in slideshow mode on the target computer. Some renderers and exported PDF/PNG previews show only the GIF's first frame.
- No audience survey or live workshop pilot yet, so visual coherence has been checked but training effectiveness is unverified.

## Assets and attribution

`assets/hand-arrow.svg`, `assets/marker-swash.svg`, and `assets/paperclip.svg` reproduce the approved SVG motif geometry from `andrekamarudin/bspt` on GitHub. Layout and usage were cross-checked against the Figma `BSPT / Reusable Brand System` specimen: handwritten notes have semantic targets, no random arrows, actual content gets notebook treatment, motion is non-looping and sparse.

`assets/brush-slash-canonical.png` is the previously generated transparent, canonical-outline raster. It does **not** contain all dry-grain specks from the complete 46 KB `logos/brush-slash.svg`. For pixel-exact fidelity, replace this raster by exporting the latest full original SVG without changing its paths; do not draw a generic substitute.

The fictional human images are generated illustrations, not customer case studies.
