const pptxgen = require('pptxgenjs');
const fs = require('fs');
const path = require('path');
const pptx = new pptxgen();
pptx.layout='LAYOUT_WIDE';
pptx.author='ByteSize ProTip';pptx.company='ByteSize ProTip';
pptx.title='Stop Babysitting AI | AI Mental OS, BSPT Field Notes v3';
pptx.subject='Editable human-centered 150-minute AI workshop';pptx.lang='en-SG';
pptx.theme={headFontFace:'Inter',bodyFontFace:'Inter',lang:'en-SG'};
const S=pptx.ShapeType;
const K={forest:'082E24',deep:'051C17',cream:'F7F2E8',orange:'FF6433',yellow:'FFD65A',stone:'E8DED0',sage:'8DAB99',ink:'17372C',white:'FFFFFF',muted:'52665B',line:'B9C6B9',light:'F0EEE5',mint:'E4EFE5',rose:'F9E9E3',gold:'D9A33F',red:'A64038',green:'1B664C'};
const W=13.333,H=7.5, photo=path.join(__dirname,'assets/cover.jpg'),mei=path.join(__dirname,'assets/mei.jpg');
const notes=JSON.parse(fs.readFileSync(path.join(__dirname,'assets/notes_v2.json'),'utf8'));

const ASSET={
  brush:path.join(__dirname,'assets/brush-slash-canonical.png'),
  animated:path.join(__dirname,'assets/bspt-brush-draw-once.gif'),
  arrow:path.join(__dirname,'assets/hand-arrow.png'),
  marker:path.join(__dirname,'assets/marker-swash.png'),
  clip:path.join(__dirname,'assets/paperclip.png'),
};
const SECTIONS=[
  {at:1,title:'01  ·  THE HUMAN PROBLEM'},
  {at:5,title:'02  ·  THE MENTAL SHIFT'},
  {at:11,title:'03  ·  DEFINE DONE'},
  {at:17,title:'04  ·  VERIFY + DELEGATE'},
  {at:23,title:'05  ·  YOUR OWN USE CASE'},
];
function currentSection(n){let a=SECTIONS[0];for(const z of SECTIONS)if(n>=z.at)a=z;return a.title;}
// A continuous line of progression is consistent across very different visual compositions.
function progressThread(s,n,dark=false){
 const muted=dark?'45675B':'D9DED1';
 rect(s,0,7.430,W,.070,muted);
 rect(s,0,7.430,W*n/26,.070,K.orange);
}
// Canonical BSPT original-derived raster at low visual weight, not a replacement logo.
function signature(s,dark=false){s.addImage({path:ASSET.brush,x:.22,y:.18,w:.36,h:.22});}
function swash(s,x,y,w,h){s.addImage({path:ASSET.marker,x,y,w,h});}
function note(s,t,x,y,w=3.0,opt={}){
 txt(s,t,x,y,w,opt.h||.48,{sz:opt.sz||23,font:'Comic Neue',bold:true,italic:true,
   color:opt.dark?'FFD65A':'BB4928',rotate:opt.rotate===undefined?-3:opt.rotate,
   align:opt.align||'left'});
}
function animatedBrush(s,x,y,w,h){
 if(fs.existsSync(ASSET.animated))s.addImage({path:ASSET.animated,x,y,w,h,
   altText:'Official BSPT brush geometry drawing from lower left to upper right; one-shot motion.'});
}
function addPaperDetails(s,x,y,w,h){
 // An actual field-note surface gets exactly one masking tape and paperclip.
 s.addShape(S.rect,{x:x+w*.40,y:y-.09,w:w*.19,h:.21,rotate:-3,
   line:{color:'F4C998',transparency:100},fill:{color:'F4C998',transparency:15}});
 s.addImage({path:ASSET.clip,x:x+w-.51,y:y-.20,w:.40,h:.58});
 ln(s,x+.40,y+.22,x+.40,y+h-.18,'E3BDB0',.85);
 for(let k=0;k<5;k++)circ(s,x+.14,y+.46+k*Math.min(.61,(h-.8)/4),.085,'F5F1E7','E4D6C7');
}
function preDecoration(s,num){
 // Exact highlighter SVG used ONLY where the highlighted phrase changes the decision.
 if(num===3)swash(s,.70,5.90,5.85,.58);
 if(num===8)swash(s,3.12,4.07,6.42,.71);
 if(num===12)swash(s,6.77,1.80,4.3,.56);
 if(num===19)swash(s,7.12,4.50,2.64,.55);
}
function postDecoration(s,num){
 if(num===1){/* cover logo motion is integrated into brand lockup */}
 if(num===2){note(s,'Sound familiar?',.93,6.76,4.6,{sz:21});}
 if(num===3){note(s,'Where is the receipt?',8.76,6.53,3.62,{sz:21,rotate:-2});}
 if(num===8){note(s,'This is the shift.',8.83,6.42,3.5,{sz:22});}
 if(num===9){note(s,'YOU decide.',9.31,2.27,2.62,{sz:23,dark:true});}
 if(num===13){s.addImage({path:ASSET.arrow,x:6.04,y:4.21,w:.52,h:.25});}
 if(num===14){note(s,'Make proof part of done.',8.52,6.57,4.2,{sz:19,rotate:-2});}
 if(num===19){note(s,'A test beats “try harder”.',7.87,6.52,4.6,{sz:20});}
 if(num===21){note(s,'Start smaller.',9.16,2.31,2.79,{sz:21});}
 if(num===23){animatedBrush(s,9.60,2.10,2.48,1.55);}
 if(num===24){note(s,'What would YOU verify?',8.03,6.60,4.63,{sz:19});}
 if(num===25){animatedBrush(s,11.10,.55,1.15,.80);}
}

let count=0;
function rect(s,x,y,w,h,fill,line=null,width=1){s.addShape(S.rect,{x,y,w,h,line:line?{color:line,width}:{color:fill,transparency:100},fill:{color:fill}})}
function round(s,x,y,w,h,fill,line=null,r=0.08){s.addShape(S.roundRect,{x,y,w,h,rectRadius:r,radius:r,line:line?{color:line,width:1.1}:{color:fill,transparency:100},fill:{color:fill}})}
function txt(s,t,x,y,w,h,opt={}){const o={x,y,w,h,fontFace:opt.font||'Inter',fontSize:opt.sz||21,color:opt.color||K.ink,bold:opt.bold||false,breakLine:false,margin:0,fit:'shrink',valign:'mid',align:opt.align||'left',lineSpacingMultiple:1,...opt};delete o.font;delete o.sz;return s.addText(t,o)}
function ln(s,x,y,x2,y2,col=K.line,sz=1,dash){s.addShape(S.line,{x,y,w:x2-x,h:y2-y,line:{color:col,width:sz,dashType:dash}})}
function circ(s,x,y,d,fill,line=null){s.addShape(S.ellipse,{x,y,w:d,h:d,fill:{color:fill},line:line?{color:line,width:1}:{color:fill,transparency:100}})}
function arrow(s,x,y,x2,y2,col=K.orange,width=3){s.addShape(S.line,{x,y,w:x2-x,h:y2-y,line:{color:col,width,beginArrowType:'none',endArrowType:'triangle'}})}
function photoSlide(s,filepath,x,y,w,h){s.addImage({path:filepath,x,y,w,h})}
function label(s,t,x,y,w=3,dark=false){txt(s,t.toUpperCase(),x,y,w,.28,{sz:10,bold:true,color:dark?K.sage:K.muted,charSpacing:1.3})}
function create(kind='cream',section='',page=true){let s=pptx.addSlide();count++;s.background={color:kind==='forest'?K.forest:kind==='deep'?K.deep:K.cream};const dark=kind!=='cream';preDecoration(s,count);progressThread(s,count,dark);if(page){const c=dark?K.sage:K.muted;signature(s,dark);label(s,'BSPT  /  FIELD NOTES',.73,.28,4,dark);label(s,currentSection(count),8.60,.28,4.3,dark);txt(s,String(count).padStart(2,'0'),12.35,7.05,.35,.18,{sz:9,bold:true,color:c,align:'right'});}if(notes[count-1])s.addNotes(notes[count-1]);return s}
function big(s,t,y,opts={}){txt(s,t,.72,y,11.85,opts.h||1,{sz:opts.sz||39,bold:true,color:opts.color||K.ink,font:opts.font||'Inter',...opts});}
function source(s,t,x,y,w,h,fill=K.white){rect(s,x,y,w,h,fill);txt(s,t,x+.2,y+.18,w-.4,h-.36,{sz:17,color:K.ink,valign:'top'})}
function pill(s,t,x,y,w,c=K.orange,fg=K.deep){round(s,x,y,w,.38,c);txt(s,t,x+.12,y+.07,w-.24,.22,{sz:11,bold:true,color:fg,align:'center'})}
function br(s,x,y,w=1.05,h=.8){ // canonical mark is embedded as an image if present; never draw a fake replica
 const markPath=path.join(__dirname,'assets/brush-slash-canonical.png');
 if(fs.existsSync(markPath))s.addImage({path:markPath,x,y,w,h});
}
function brand(s,x=.7,y=.67,dark=false){txt(s,'ByteSize ProTip',x,y,4.9,.55,{sz:26,bold:true,color:dark?K.cream:K.forest,font:'Georgia'});br(s,x+3.20,y-.04,.96,.66)}
function check(s,x,y,yes=true){circ(s,x,y,.29,yes?K.green:K.red);txt(s,yes?'✓':'×',x+.04,y+.016,.22,.21,{sz:17,bold:true,color:K.white,align:'center'})}
function paper(s,x,y,w,h,rot=0){s.addShape(S.rect,{x,y,w,h,rotate:rot,fill:{color:K.white},line:{color:K.stone,width:1.1},shadow:{type:'outer',color:'000000',opacity:.12,blur:2.5,angle:45,distance:1.5}});addPaperDetails(s,x,y,w,h)}
function heading(s,eyebrow,title,opts={}){label(s,eyebrow,.72,.85,6,opts.dark);txt(s,title,.72,1.24,11.95,1.17,{sz:opts.sz||35,bold:true,color:opts.dark?K.cream:K.ink,font:'Inter',breakLine:false});}
function tinyNote(s,text,x=.75,y=6.72,w=11.6,dark=false){txt(s,text,x,y,w,.3,{sz:14,color:dark?K.sage:K.muted})}
// 01 Cover: one human moment with legible promise
{
 const s=create('deep','PAID WORKSHOP · 150 MIN',false);photoSlide(s,photo,0,0,W,H);
 rect(s,0,0,7.0,H,K.deep); // purposefully hard editorial edge, no fake opacity
 rect(s,6.75,0,.25,H,K.orange);
 brand(s,.76,.75,true);label(s,'THE AI MENTAL OS',.76,1.48,5.5,true);
 txt(s,'STOP\nBABYSITTING\nAI.',.76,2.15,6.2,3.18,{sz:56,bold:true,color:K.cream,breakLine:false});
 txt(s,'Keep the why. Delegate the how.\nMake “done” provable.',.78,5.78,5.7,.88,{sz:22,color:K.sage});
}
// 02 Human problem: cinematic split
{
 const s=create('cream','HUMAN PROBLEM');photoSlide(s,mei,7.50,.63,5.83,6.87);
 label(s,'A familiar moment / fictional case',.76,1.13,6.1);
 txt(s,'“I asked AI to\nsave me time.\nNow I check\nevery line.”',.75,1.68,6.45,3.61,{sz:42,bold:true,color:K.forest,breakLine:false});
 ln(s,.78,5.62,5.65,5.62,K.orange,7);
 txt(s,'Mei · 5:44 PM',.78,6.12,4.7,.45,{sz:22,bold:true,color:K.ink});
}
// 03 Evidence in source note
{
 const s=create('cream','THE MISTAKE');
 heading(s,'Problem','A polished sentence created a fake commitment.',{sz:34});
 rect(s,.75,2.60,5.6,2.55,K.light);
 label(s,'Fictional source notes',.98,2.84,4.7);txt(s,'Maya: “Let’s test with 10 users.”\nDan: “I can draft the invite.”\nAlex: “I need to check my schedule.”',.98,3.35,5.0,1.45,{sz:22,color:K.ink,valign:'top'});
 rect(s,6.82,2.60,5.75,2.55,K.rose);
 label(s,'AI-generated summary',7.08,2.84,4.8);txt(s,'“Alex owns the rollout.\nEveryone approved the date.”',7.05,3.40,5.11,1.36,{sz:25,bold:true,color:K.red});
 ln(s,5.7,5.60,12.57,5.60,K.orange,5);
 txt(s,'Nothing in the source supports that commitment.',.75,5.91,11.6,.58,{sz:25,bold:true,color:K.forest});
}
// 04 Show transition with two different visual worlds
{
 const s=create('cream','THE HUMAN CHANGE');
 rect(s,0,0,6.35,H,K.light);rect(s,6.35,0,6.983,H,K.forest);
 label(s,'Before: human in the loop',.77,1.12,5.25);txt(s,'ASK\nCHECK\nFIX\nREPEAT',.80,1.8,4.95,3.86,{sz:53,bold:true,color:K.red,breakLine:false});
 label(s,'After: human above the loop',7.12,1.12,5,true);txt(s,'DESIGN\nDIRECT\nREVIEW EXCEPTIONS',7.10,1.89,5.28,3.75,{sz:38,bold:true,color:K.cream,breakLine:false});
 arrow(s,5.75,3.76,7.02,3.76,K.orange,7);
 txt(s,'From operator to architect.',7.10,6.05,5.3,.57,{sz:25,bold:true,color:K.yellow});
}
// 05 paid value
{
 const s=create('forest','THE PROMISE');
 txt(s,'FREE:',.83,1.3,2.15,.53,{sz:25,bold:true,color:K.sage});txt(s,'24 useful AI prompts.',.83,2.00,11.5,.7,{sz:34,color:K.cream});
 ln(s,.82,3.09,12.52,3.09,K.sage,1.3);
 txt(s,'PAID:',.83,3.44,2.15,.53,{sz:25,bold:true,color:K.yellow});
 txt(s,'The ability to invent\nyour own 25th.',.83,4.10,11.5,1.77,{sz:46,bold:true,color:K.cream,breakLine:false});
 txt(s,'That is the skill we are building today.',.83,6.41,11.6,.52,{sz:21,color:K.sage});
}
// 06 learner reflection
{
 const s=create('cream','BASELINE EXERCISE');
 heading(s,'First: a human job','What would you stop doing by hand?',{sz:36});
 txt(s,'I want to stop manually…',.94,3.00,11.45,.68,{sz:35,bold:true,color:K.forest});
 ln(s,.94,4.02,12.08,4.02,K.stone,2);
 txt(s,'So that…',.94,4.55,11.45,.68,{sz:35,bold:true,color:K.forest});
 ln(s,.94,5.57,12.08,5.57,K.stone,2);
 pill(s,'3 MIN · PRIVATE REFLECTION',.93,6.1,3.4,K.orange,K.deep);
}
// 07 technical model as physical stack
{
 const s=create('cream','JUST ENOUGH TECH');
 heading(s,'Technical reality','The model is not the whole system.');
 const xs=[.81,3.96,7.10,10.24]; const nodes=[['MODEL','Generates'],['CONTEXT','What it sees'],['TOOLS','What it can act on'],['CHECKS','What can be proved']];
 xs.forEach((x,i)=>{circ(s,x+.5,2.95,1.65,i===3?K.orange:K.forest);txt(s,String(i+1),x+.92,3.35,.80,.65,{sz:34,bold:true,color:i===3?K.deep:K.cream,align:'center'});txt(s,nodes[i][0],x,4.90,2.7,.48,{sz:22,bold:true,color:K.forest,align:'center'});txt(s,nodes[i][1],x,5.44,2.7,.38,{sz:17,color:K.muted,align:'center'});if(i<3)arrow(s,x+2.1,3.8,x+3.05,3.8,K.orange,2.2)});
 rect(s,.83,6.22,11.66,.59,K.mint);txt(s,'YOU set the outcome and boundaries. The system performs the work.',1.05,6.35,11.2,.31,{sz:18,bold:true,color:K.forest});
}
// 08 headline pair, no 2-card dashboard
{
 const s=create('cream','TWO PILLARS');
 txt(s,'01',.77,1.37,2.18,1.05,{sz:83,bold:true,color:K.forest});
 txt(s,'HUMAN\nABOVE THE LOOP',3.20,1.32,9.0,1.73,{sz:43,bold:true,color:K.forest,breakLine:false});
 ln(s,.77,3.52,12.48,3.52,K.stone,2);
 txt(s,'02',.77,4.02,2.18,1.05,{sz:83,bold:true,color:K.forest});
 txt(s,'OUTCOMES YOU\nCAN PROVE',3.20,3.97,9.0,1.73,{sz:43,bold:true,color:K.forest,breakLine:false});
 tinyNote(s,'The only two principles to remember. Everything else is supporting technique.',.78,6.78,11.9);
}
// 09 human above loop in diagram
{
 const s=create('forest','PILLAR ONE');
 txt(s,'DIRECT THE WORK.',.76,1.00,11.6,.70,{sz:38,bold:true,color:K.cream});
 txt(s,'Let the AI do the permitted work and run its checks.',.80,1.85,11.5,.48,{sz:19,color:K.sage});
 round(s,4.68,2.45,4.0,.89,K.orange);txt(s,'HUMAN: Outcome + boundaries',4.86,2.65,3.63,.38,{sz:18,bold:true,color:K.deep,align:'center'});
 arrow(s,6.70,3.36,6.70,4.08,K.yellow,2.6);
 round(s,4.68,4.09,4.0,.88,K.cream);txt(s,'AI: Execute + check + repair',4.88,4.31,3.57,.40,{sz:18,bold:true,color:K.forest,align:'center'});
 arrow(s,4.68,4.52,2.75,5.40,K.sage,2.2);arrow(s,8.68,4.52,10.65,5.40,K.sage,2.2);
 round(s,.90,5.43,3.80,.8,'285D48');txt(s,'PASS → deliver result',1.1,5.62,3.41,.35,{sz:19,bold:true,color:K.cream});
 round(s,8.64,5.43,3.81,.8,'613D32');txt(s,'EXCEPTION → human',8.82,5.60,3.44,.40,{sz:18,bold:true,color:K.cream});
}
// 10 lanes with clearly defined examples
{
 const s=create('cream','AUTHORITY BOUNDARIES');heading(s,'The nonnegotiable limit','Autonomy follows risk, not enthusiasm.',{sz:35});
 const ys=[2.73,3.88,5.03], col=[K.mint,'FFF1D8',K.rose], t=[['ROUTINE','Format, classify, test','AI may proceed within scope'],['AMBIGUOUS','Conflicting sources, unclear stakes','Escalate judgment'],['CONSEQUENTIAL','Send, spend, delete, protected data','Exact approval before action']];
 ys.forEach((y,i)=>{rect(s,.80,y,11.7,1.02,col[i]);rect(s,.8,y,.14,1.02,[K.green,K.gold,K.red][i]);txt(s,t[i][0],1.16,y+.16,2.68,.43,{sz:21,bold:true,color:K.forest});txt(s,t[i][1],3.55,y+.16,4.44,.45,{sz:19,color:K.ink});txt(s,t[i][2],8.25,y+.20,3.89,.40,{sz:16,bold:true,color:i===2?K.red:K.forest});});
}
// 11 contract as giant three-part mental model
{
 const s=create('forest','PILLAR TWO');
 txt(s,'OUTCOME.',.76,1.03,11.9,1.24,{sz:67,bold:true,color:K.cream});
 txt(s,'PROOF.',.76,2.47,11.9,1.24,{sz:67,bold:true,color:K.orange});
 txt(s,'BOUNDARIES.',.76,3.91,11.9,1.24,{sz:67,bold:true,color:K.cream});
 ln(s,.79,5.77,12.46,5.77,K.sage,1.5);
 txt(s,'Define all three before asking the model to begin.',.80,6.08,11.6,.54,{sz:23,color:K.sage});
}
// 12 weak vs strong request, clearly proof
{
 const s=create('cream','TRANSFORMATION');
 label(s,'Weak request',.78,1.25,5);txt(s,'“Summarize\nthese notes.”',.78,1.87,4.85,1.60,{sz:41,bold:true,color:K.red,breakLine:false});
 label(s,'Outcome contract',6.78,1.25,5);txt(s,'“Identify decisions,\nquote source lines,\nflag unknowns.”',6.79,1.79,5.57,2.30,{sz:30,bold:true,color:K.forest,breakLine:false});
 arrow(s,5.65,3.13,6.55,3.13,K.orange,5);
 rect(s,.82,4.78,11.67,1.25,K.mint);
 txt(s,'The better request makes unsupported conclusions easier to catch.',1.12,5.10,11.1,.68,{sz:24,bold:true,color:K.forest});
}
// 13 source and output traceability
{
 const s=create('cream','EVIDENCE, NOT VIBES');
 heading(s,'Concrete demonstration','A proposal is not a decision.');
 rect(s,.78,2.48,5.32,3.41,K.white);label(s,'Fictional meeting notes',1.04,2.74,4.64);
 ['1   Maya: “Test with 10 users.”','2   Dan: “I will draft invite.”','3   Maya: “Let’s start Monday.”','4   Alex: “I need to check.”'].forEach((t,i)=>txt(s,t,1.01,3.27+i*.51,4.85,.33,{sz:19,color:K.ink}));
 rect(s,6.51,2.48,5.99,3.41,K.mint);label(s,'Traceable decision register',6.81,2.74,5.0);
 const out=[['PROPOSED','Test with 10 users','LINE 1'],['ACTION','Dan drafts invite','LINE 2'],['UNKNOWN','Alex’s approval','LINE 4']];
 out.forEach((x,i)=>{let y=3.26+i*.76;txt(s,x[0],6.79,y,1.73,.35,{sz:16,bold:true,color:i===2?K.red:K.forest});txt(s,x[1],8.48,y,2.65,.35,{sz:17,color:K.ink});txt(s,x[2],11.25,y,.95,.34,{sz:13,bold:true,color:K.green});});
 txt(s,'Fictional data: the source is the receipt, not AI confidence.',.83,6.39,11.6,.42,{sz:17,color:K.muted});
}
// 14 contract document with open lines not cards
{
 const s=create('cream','WORK BRIEF');
 heading(s,'The contract','Write what “done” looks like.',{sz:36});
 paper(s,1.05,2.36,11.15,3.87,0);
 const items=[['01','HUMAN OUTCOME','Who needs what changed?'],['02','DELIVERABLE','What exactly should exist?'],['03','ACCEPTANCE','What must pass?'],['04','EVIDENCE','What will demonstrate the result?'],['05','BOUNDARIES','When to stop or ask?']];
 items.forEach((v,i)=>{const y=2.59+i*.69;txt(s,v[0],1.36,y,.55,.37,{sz:19,bold:true,color:K.forest});txt(s,v[1],2.22,y,3.17,.40,{sz:19,bold:true,color:K.forest});txt(s,v[2],5.47,y,6.3,.4,{sz:18,color:K.muted});if(i<4)ln(s,1.4,y+.55,11.78,y+.55,K.stone,1)});
}
// 15 practice visual pause with clear time
{
 const s=create('forest','GUIDED PRACTICE');
 txt(s,'18',.80,1.24,4.2,2.11,{sz:131,bold:true,color:K.orange});txt(s,'MINUTES',5.24,1.99,6.75,.84,{sz:44,bold:true,color:K.cream});
 ln(s,.79,3.67,12.36,3.67,K.sage,1.8);
 txt(s,'WRITE A REAL OUTCOME CONTRACT',.80,4.03,11.45,.60,{sz:33,bold:true,color:K.cream});
 txt(s,'Deliver: one human goal, three pass checks, one approval boundary.',.81,5.10,11.55,1.06,{sz:25,color:K.sage});
 pill(s,'PAIR REVIEW AFTER THE FIRST 10 MIN',.81,6.43,4.38,K.yellow,K.deep);
}
// 16 break : reflection
{
 const s=create('deep','BREAK',false);
 txt(s,'10',.90,1.08,7.0,2.30,{sz:155,bold:true,color:K.orange});
 txt(s,'MINUTE BREAK',.98,3.56,10.66,1.25,{sz:61,bold:true,color:K.cream});
 txt(s,'A good AI brief is simply a good work brief.',.99,5.45,11.2,.75,{sz:27,color:K.sage});
}
// 17 checks in 4 distinct artifacts rather than cards
{
 const s=create('cream','CHECKING THE WORK');heading(s,'Build the receipt','Choose a checker that matches the failure.');
 const labels=[['ARITHMETIC','2 × 0.5 h × $20 = $20'],['SOURCE','“Decided” → quote line 3'],['RENDER','Preview all 26 slides'],['JUDGMENT','Human validates intended meaning']];
 labels.forEach((z,i)=>{const x=i%2?7.05:.80,y=i>=2?4.69:2.62;ln(s,x,y,x+5.35,y,K.orange,3);txt(s,z[0],x,y+.21,5.3,.37,{sz:18,bold:true,color:K.forest});txt(s,z[1],x,y+.70,5.4,.90,{sz:23,color:K.ink,valign:'top'});});
}
// 18 bounded process with directional truth
{
 const s=create('forest','RUN THE LOOP');
 txt(s,'A GOOD LOOP\nCAN STOP.',.78,1.13,11.90,1.89,{sz:50,bold:true,color:K.cream,breakLine:false});
 const step=[['1','PRODUCE'],['2','CHECK'],['3','REPAIR'],['4','DELIVER']];
 step.forEach((x,i)=>{let xx=.78+i*3.08;circ(s,xx,3.73,.64,i===1?K.orange:K.cream);txt(s,x[0],xx+.11,3.88,.41,.30,{sz:21,bold:true,color:K.deep,align:'center'});txt(s,x[1],xx,4.64,2.62,.51,{sz:22,bold:true,color:K.cream});if(i<3)arrow(s,xx+.8,4.05,xx+2.56,4.05,K.yellow,3);});
 txt(s,'If FAIL: report mismatch, retry within limits.\nIf UNKNOWN: surface the exception.',.78,5.88,11.62,.82,{sz:23,color:K.sage});
}
// 19 failure vs targeted repair
{
 const s=create('cream','FAILURE REPAIR');heading(s,'A good correction','“8 rows found. 9 expected.”',{sz:36});
 txt(s,'8',1.00,3.07,3.25,1.86,{sz:132,bold:true,color:K.red});txt(s,'≠',4.20,3.27,2.56,1.47,{sz:102,bold:true,color:K.muted,align:'center'});txt(s,'9',7.24,3.07,3.08,1.86,{sz:132,bold:true,color:K.green});
 txt(s,'Restore the missing source row. Rerun the count.',.91,5.58,11.6,.79,{sz:26,bold:true,color:K.forest});
}
// 20 PASS FAIL UNKNOWN receipt
{
 const s=create('cream','YOUR RECEIPT');heading(s,'Practice: 5 minutes','Can you label the result honestly?',{sz:33});
 const entries=[['PASS','3 rows expected. 3 source rows retained.'],['FAIL','3 rows expected. Only 2 rows returned.'],['UNKNOWN','One action has no supporting source.']];
 entries.forEach((v,i)=>{const y=2.58+i*1.13;rect(s,.82,y,11.72,.91,[K.mint,K.rose,'FFF1D8'][i]);txt(s,v[0],1.12,y+.22,2.47,.42,{sz:25,bold:true,color:[K.green,K.red,'8C5C16'][i]});txt(s,v[1],3.58,y+.18,8.35,.52,{sz:21,color:K.forest});});
 tinyNote(s,'A model praising itself is not an independent receipt.',.92,6.41,11.55);
}
// 21 automation ladder as real staircase
{
 const s=create('cream','SYSTEMS, NOT HYPE');heading(s,'Keep it simple','Agents are optional. Reliable work is the goal.',{sz:34});
 const levels=[['CHAT','One task'],['TEMPLATE','Repeatable'],['WORKFLOW','Checked steps'],['AGENT','Dynamic tool use']];
 levels.forEach((v,i)=>{let x=.90+i*3.05,y=5.7-i*.85;rect(s,x,y,2.72,1.05+i*.85,i===3?K.forest:i===2?K.mint:K.white);txt(s,String(i+1),x+.21,y+.24,.65,.43,{sz:29,bold:true,color:i===3?K.yellow:K.forest});txt(s,v[0],x+.86,y+.29,1.76,.34,{sz:18,bold:true,color:i===3?K.cream:K.forest});txt(s,v[1],x+.15,y+.65,2.35,.29,{sz:14,color:i===3?K.sage:K.muted});});
}
// 22 permission gate
{
 const s=create('forest','GOVERN EXCEPTIONS');
 txt(s,'THE RED LINE\nIS AN APPROVAL GATE.',.73,1.06,12.0,1.65,{sz:42,bold:true,color:K.cream,breakLine:false});
 const steps=[['DRAFT','Safe'],['CHECK','Safe'],['PREVIEW','Review'],['SEND','Approval']];
 steps.forEach((v,i)=>{const x=.90+i*3.06;rect(s,x,3.28,2.61,1.18,i===3?K.rose:K.cream);txt(s,v[0],x+.16,3.53,2.30,.43,{sz:23,bold:true,color:i===3?K.red:K.forest,align:'center'});txt(s,v[1],x+.15,4.11,2.30,.25,{sz:14,color:i===3?K.red:K.muted,align:'center'});if(i<3)arrow(s,x+2.64,3.86,x+3.0,3.86,K.orange,2.4)});
 ln(s,10.00,2.96,10.00,5.02,K.orange,4,'dash');
 txt(s,'A draft never authorizes its own send.',.94,5.88,11.6,.56,{sz:25,bold:true,color:K.sage});
}
// 23 capstone
{
 const s=create('forest','NOVEL USE CASE');
 txt(s,'THE',.77,1.06,3.07,.83,{sz:41,color:K.cream});
 txt(s,'25th',.75,1.97,7.0,2.32,{sz:143,bold:true,color:K.orange});
 txt(s,'IS YOURS.',.81,4.49,10.3,.87,{sz:54,bold:true,color:K.cream});
 txt(s,'A new human problem. Your own contract. Checkable proof.',.82,6.10,11.7,.58,{sz:22,color:K.sage});
}
// 24 capstone worksheet readable
{
 const s=create('cream','20-MIN CAPSTONE');heading(s,'Now demonstrate it','Build one Outcome Contract you can defend.',{sz:33});
 paper(s,.88,2.43,11.70,3.84,0);
 const items=[['WHO','What human problem changes?'],['WHAT','What deliverable will exist?'],['DONE','What three checks prove it?'],['STOP','What is blocked or escalated?'],['RETURN','What receipt will you receive?']];
 items.forEach((z,i)=>{const y=2.66+i*.70;txt(s,z[0],1.17,y,1.61,.40,{sz:20,bold:true,color:K.forest});txt(s,z[1],2.95,y,8.88,.40,{sz:22,color:K.forest});ln(s,1.17,y+.57,12.13,y+.57,K.stone,1)});
}
// 25 payoff: editorial contrast, no admin checklist
{
 const s=create('deep','THE PAYOFF',false);
 br(s,11.1,.55,1.15,.80);
 txt(s,'YOU OWN\nTHE WHY.',.75,1.19,11.87,2.30,{sz:69,bold:true,color:K.cream,breakLine:false});
 ln(s,.82,4.04,12.52,4.04,K.orange,7);
 txt(s,'DELEGATE\nTHE HOW.',.75,4.30,11.87,1.86,{sz:57,bold:true,color:K.orange,breakLine:false});
 txt(s,'Make done provable.',.79,6.52,10.40,.43,{sz:23,color:K.sage});
}
// 26 references appendix; well typed, notes contain full links
{
 const s=create('cream','INSTRUCTOR APPENDIX');
 heading(s,'Reference notes','What supports this training design?',{sz:33});
 const data=[['Anthropic','Building effective agents · workflows and feedback'],['OpenAI','Practical guide to building AI agents · guardrails'],['NIST','Generative AI Profile · risk management'],['National Academies','How People Learn · transfer to new tasks'],['BSPT','Original curriculum synthesis and fictional demonstrations']];
 data.forEach((z,i)=>{const y=2.52+i*.81;txt(s,z[0],.87,y,3.60,.38,{sz:19,bold:true,color:K.forest});txt(s,z[1],4.29,y,7.90,.42,{sz:18,color:K.muted});if(i<4)ln(s,.87,y+.57,12.33,y+.57,K.stone,1)});
 tinyNote(s,'Presenter sources and caveats remain in notes; no measured pilot efficacy is claimed.',.88,6.77,11.8);
}
for(let i=0;i<pptx._slides.length;i++)postDecoration(pptx._slides[i],i+1);
if(count!==26)throw Error('Unexpected slide count '+count);
pptx.writeFile({fileName:path.join(__dirname,'BSPT_AI_Mental_OS_Training_v3.pptx')}).then(()=>console.log('Created',count,'slides')).catch(e=>{console.error(e);process.exit(1)});
