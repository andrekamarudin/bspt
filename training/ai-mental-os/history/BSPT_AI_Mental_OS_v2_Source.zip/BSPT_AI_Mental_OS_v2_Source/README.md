# BSPT AI Mental OS v2: editable deck source

This package recreates the 26-slide, 150-minute PowerPoint with editable PPTX text, shapes, diagrams and facilitator notes.

## Build

1. Install Node.js 20 or newer.
2. Run `npm install` in this folder.
3. Run `npm run build`.
4. Open `BSPT_AI_Mental_OS_Training_v2.pptx`.

The generator uses PptxGenJS. Source photographs are illustrative AI-generated fiction, **not real customers or endorsements**. Do not identify them as a real participant.

The decorative orange slash mark was reconstructed from the **exact outline coordinates** of the three filled paths in `andrekamarudin/bspt/logos/brush-slash.svg`, then rasterized at high resolution for PowerPoint compatibility. Fine original dry-grain mask and hand-drawn accent paths are not present in this derivative; for exact pixel fidelity, replace this derivative with a raster export of the canonical full SVG. No generic logo or substitute identity was invented.

Brand source: `andrekamarudin/bspt/brand/tokens.json`. Presentation headings use Inter and a Georgia fallback for the editorial serif. Font substitution may alter layout across operating systems. Re-render after changing fonts.

## QA and fidelity

- The complete `.pptx` passed the slides structural/overflow test and all 26 pages were rendered and inspected as a contact sheet.
- The 25 taught slides have facilitator notes totaling 150 minutes. Slide 26 is instructor-only references.
- Slides are editable, but the illustrative image and brush mark are raster assets.
- Test actual demos and participant exercises with an approved AI client before delivering the paid session.

No confidential or private customer data is used in this deck. Source excerpts and meeting notes are fictional.
